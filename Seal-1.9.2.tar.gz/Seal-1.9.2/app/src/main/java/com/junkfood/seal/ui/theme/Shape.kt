package com.junkfood.seal.ui.theme

import androidx.compose.material3.Shapes

val Shapes = Shapes(
)